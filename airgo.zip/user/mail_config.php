<?php
// Email Configuration
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);
define('SMTP_USERNAME', 'honeymardsflores020602@gmail.com');     // Your Gmail address
define('SMTP_PASSWORD', 'bljuvllnxbzbrqzg');       // Your Gmail App Password
define('SMTP_FROM_EMAIL', 'honeymardsflores020602@gmail.com');   // Same as SMTP_USERNAME
define('SMTP_FROM_NAME', 'Airgo Aircon Cleaning');

// Additional SMTP settings
define('SMTP_SECURE', 'tls');
define('SMTP_AUTH', true);
define('SMTP_DEBUG', 0);  // Set to 2 for debugging

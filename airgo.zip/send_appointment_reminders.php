<?php
// Set error reporting for debugging (remove in production)
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('log_errors', 1);
ini_set('error_log', dirname(__FILE__) . '/error_log');

// Get the base path
define('BASE_PATH', dirname(__FILE__));

// Include required files
require BASE_PATH . '/vendor/autoload.php';
require BASE_PATH . '/mail_config.php';
require BASE_PATH . '/db_connection.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Function to send email
function sendReminderEmail($to, $subject, $message) {
    $mail = new PHPMailer(true);

    try {
        // Server settings
        $mail->isSMTP();
        $mail->Host = SMTP_HOST;
        $mail->SMTPAuth = SMTP_AUTH;
        $mail->Username = SMTP_USERNAME;
        $mail->Password = SMTP_PASSWORD;
        $mail->SMTPSecure = SMTP_SECURE;
        $mail->Port = SMTP_PORT;

        // Recipients
        $mail->setFrom(SMTP_FROM_EMAIL, SMTP_FROM_NAME);
        $mail->addAddress($to);

        // Content
        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body = $message;

        $mail->send();
        error_log("Successfully sent email to: " . $to);
        return true;
    } catch (Exception $e) {
        error_log("Email sending failed to {$to}: " . $mail->ErrorInfo);
        return false;
    }
}

// Get current date and time in Philippines timezone
date_default_timezone_set('Asia/Manila');
$currentDate = date('Y-m-d');
$currentTime = date('H:i:s');
$tomorrowDate = date('Y-m-d', strtotime('+1 day'));

try {
    // Query for appointments tomorrow
    $tomorrowQuery = "SELECT b.*, u.email, u.first_name, u.last_name 
                     FROM bookings b 
                     JOIN users u ON b.user_id = u.id 
                     WHERE DATE(b.appointment_date) = ? 
                     AND b.status = 'confirmed'";

    $stmt = $conn->prepare($tomorrowQuery);
    $stmt->bind_param("s", $tomorrowDate);
    $stmt->execute();
    $tomorrowResults = $stmt->get_result();

    // Send reminders for tomorrow's appointments
    while ($booking = $tomorrowResults->fetch_assoc()) {
        $appointmentTime = date('h:i A', strtotime($booking['appointment_date']));
        $subject = "Reminder: Your Airgo Appointment Tomorrow";
        $message = "
            <html>
            <body>
                <h2>Appointment Reminder</h2>
                <p>Dear {$booking['first_name']} {$booking['last_name']},</p>
                <p>This is a friendly reminder that you have an appointment scheduled for tomorrow at {$appointmentTime}.</p>
                <p>Service: {$booking['service_type']}</p>
                <p>Location: {$booking['address']}</p>
                <p>If you need to make any changes, please contact us as soon as possible.</p>
                <p>Thank you for choosing Airgo Aircon Cleaning!</p>
            </body>
            </html>
        ";
        
        sendReminderEmail($booking['email'], $subject, $message);
    }

    // Query for today's appointments (if current time is 5 AM)
    if (date('H') == '05' && date('i') < 15) { // Run between 5:00 AM and 5:15 AM
        $todayQuery = "SELECT b.*, u.email, u.first_name, u.last_name 
                       FROM bookings b 
                       JOIN users u ON b.user_id = u.id 
                       WHERE DATE(b.appointment_date) = ? 
                       AND b.status = 'confirmed'";

        $stmt = $conn->prepare($todayQuery);
        $stmt->bind_param("s", $currentDate);
        $stmt->execute();
        $todayResults = $stmt->get_result();

        // Send reminders for today's appointments
        while ($booking = $todayResults->fetch_assoc()) {
            $appointmentTime = date('h:i A', strtotime($booking['appointment_date']));
            $subject = "Today's Airgo Appointment Reminder";
            $message = "
                <html>
                <body>
                    <h2>Today's Appointment Reminder</h2>
                    <p>Dear {$booking['first_name']} {$booking['last_name']},</p>
                    <p>This is a reminder that you have an appointment scheduled for today at {$appointmentTime}.</p>
                    <p>Service: {$booking['service_type']}</p>
                    <p>Location: {$booking['address']}</p>
                    <p>Please ensure you are available at the scheduled time.</p>
                    <p>Thank you for choosing Airgo Aircon Cleaning!</p>
                </body>
                </html>
            ";
            
            sendReminderEmail($booking['email'], $subject, $message);
        }
    }
} catch (Exception $e) {
    error_log("Database error: " . $e->getMessage());
} finally {
    $conn->close();
}

// Log script completion
error_log("Reminder script completed at " . date('Y-m-d H:i:s')); 
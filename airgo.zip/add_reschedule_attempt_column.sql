ALTER TABLE bookings
ADD COLUMN reschedule_attempt INT DEFAULT 0; 